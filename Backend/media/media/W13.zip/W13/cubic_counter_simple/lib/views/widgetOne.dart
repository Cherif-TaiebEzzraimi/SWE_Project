import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/counter_cubit.dart';

class WidgetOne extends StatelessWidget {
  const WidgetOne({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Text(
        'Value is :',
        style: TextStyle(fontSize: 30),
      ),
      BlocBuilder<CounterCubit, Map<String, dynamic>>(
        builder: (context, data) {
          if (data['state'] == 'loading') {
            return CircularProgressIndicator();
          }
          return Text(
            key:Key('counter_result_1'),
            '${data['counter']}',
            style: TextStyle(fontSize: 30),
          );
        },
      ),
      ElevatedButton(
          onPressed: () {
            var gg = context.read<CounterCubit>();
            gg.increment();
          },
          key: Key('increment_button'),
          child: Text('Increment')),
    ]);
  }
}
