import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../bloc/counter_cubit.dart';

class WidgetTwo extends StatelessWidget {
  const WidgetTwo({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CounterCubit, Map<String, dynamic>>(
      builder: (context, data) {
        return Text(
          key: Key('counter_result_2'),
          'Double of Increment is : ${2 * data['counter']}',
          style: TextStyle(fontSize: 30),
        );
      },
    );
  }
}
