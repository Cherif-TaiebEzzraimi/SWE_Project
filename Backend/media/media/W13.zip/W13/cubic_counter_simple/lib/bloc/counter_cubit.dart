import 'package:bloc/bloc.dart';

class CounterCubit extends Cubit<Map<String, dynamic>> {
  CounterCubit() : super({'state': 'done', 'counter': 0});

  void increment() async {
    print('Old State $state');
    var aaa = {'state': 'loading', 'counter': state['counter']};
    emit(aaa);
    print('new State1 $state');
    await Future.delayed(Duration(seconds: 5));
    var abc = {'state': 'done', 'counter': state['counter'] + 1};
    emit(abc);
    print('new State2 $state');
  }

  void decrement() {
    print('Old State $state');
    var abc = {'state': 'done', 'counter': state['counter'] - 1};
    emit(abc);
    print('new State $state');
  }
}
