import 'package:bloc_test/bloc_test.dart';
import 'package:cubic_counter_simple/bloc/counter_cubit.dart';
import 'package:flutter/material.dart';
import 'package:test/test.dart';

void main() {
  test('Hello World', () async {
    WidgetsFlutterBinding.ensureInitialized();
    expect(1, 1);
  });

  blocTest<CounterCubit, Map<String, dynamic>>(
    'Test the CounterCubit BloC/Cubit.',
    build: () => CounterCubit(),
    act: (cubit) => cubit.increment(),
    expect: () => [
      {'state': 'loading', 'counter': 0},
      {'state': 'done', 'counter': 1},
    ],
  );

  // blocTest<CounterCubit, Map<String, dynamic>>(
  //   'emits [1] when increment is called, faking an error, by expecting 1 instead.',
  //   build: () => CounterCubit(),
  //   act: (cubit) => cubit.increment(),
  //   expect: () => [1],
  // );
}
