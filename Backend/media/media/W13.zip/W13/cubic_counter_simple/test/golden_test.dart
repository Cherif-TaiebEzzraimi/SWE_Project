import 'package:cubic_counter_simple/bloc/counter_cubit.dart';
import 'package:cubic_counter_simple/views/homescreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:golden_toolkit/golden_toolkit.dart';

void main() {
  testGoldens('HomeScreen full screen golden test', (tester) async {
    // Wrap screen in MaterialApp to provide context
    final screen = MultiBlocProvider(
        providers: [
          BlocProvider(create: (_) => CounterCubit()),
        ],
        child: MaterialApp(
          home: HomeScreen(),
        ));

    await tester.pumpWidgetBuilder(screen, surfaceSize: Size(400, 800));

    await screenMatchesGolden(tester, 'counter_app');
  });

  
}
