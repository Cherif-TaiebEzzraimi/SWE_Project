import 'package:cubic_counter_simple/bloc/counter_cubit.dart';
import 'package:cubic_counter_simple/views/homescreen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:integration_test/integration_test.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('App integration test example', (tester) async {
    //Call : init_my_app()  in case...

    await tester.pumpWidget(MultiBlocProvider(
        providers: [
          BlocProvider(create: (_) => CounterCubit()),
        ],
        child: MaterialApp(
          home: HomeScreen(),
        )));

    await tester.pumpAndSettle();

    // Tap login button
    await tester.tap(find.byKey(Key('increment_button')));
    await tester.pumpAndSettle();

    final text_one = find.byKey(Key('counter_result_1'));
    expect(text_one, findsOneWidget);
    final text_two = find.byKey(Key('counter_result_2'));
    expect(text_two, findsOneWidget);

    Text textWidget_1 = tester.widget(text_one);
    expect(textWidget_1.data, '1');

    Text textWidget_2 = tester.widget(text_two);
    expect(textWidget_2.data, 'Double of Increment is : 2');
  });
}
