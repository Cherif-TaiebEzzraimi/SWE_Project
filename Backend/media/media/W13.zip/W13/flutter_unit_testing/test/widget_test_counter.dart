import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_unit_testing/screens/home.dart';
import 'package:flutter_unit_testing/utils/counter.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  testWidgets('Clicking Increment button', (tester) async {
    WidgetsFlutterBinding.ensureInitialized();

    SharedPreferences.setMockInitialValues({});
    await counter.init();
    await counter.reset();

    // Build the widget.
    await tester.pumpWidget(MaterialApp(
      home: HomeScreen(),
    ));

    expect(find.text("Increment"), findsOneWidget);
    await tester.tap(find.text("Increment"));
    await tester.tap(find.text("Increment"));
    await tester.pump();
    expect(find.textContaining("Value is : 2"), findsOneWidget);
  });
}
