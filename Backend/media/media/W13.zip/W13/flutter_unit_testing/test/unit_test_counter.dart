import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_unit_testing/main.dart';
import 'package:flutter_unit_testing/utils/counter.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  test('Counter value should be incremented', () async {
    WidgetsFlutterBinding.ensureInitialized();
    SharedPreferences.setMockInitialValues({});
    final counter = Counter();
    await counter.init();
    await counter.reset();
    await counter.increment();

    expect(counter.getValue(), 1);
  });
}
