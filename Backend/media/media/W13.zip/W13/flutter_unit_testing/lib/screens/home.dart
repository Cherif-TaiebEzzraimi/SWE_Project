import 'package:flutter/material.dart';
import 'package:flutter_unit_testing/main.dart';

import '../utils/counter.dart';

final counter = Counter();

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: Text("Counter using SharedPref ")),
        body: Center(
            child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text("Value is : ${counter.getValue()}"),
            SizedBox(height: 20),
            ElevatedButton(
                onPressed: () async {
                  counter.increment().then(
                    (value) {
                      setState(() {});
                    },
                  );
                },
                child: Text("Increment")),
            SizedBox(height: 20),
            ElevatedButton(
                onPressed: () async {
                  counter.decrement().then(
                    (value) {
                      setState(() {});
                    },
                  );
                },
                child: Text("Decrement")),
          ],
        )));
  }
}
