import 'package:shared_preferences/shared_preferences.dart';

class Counter {
  late SharedPreferences prefs;

  init() async {
    prefs = await SharedPreferences.getInstance();
  }

  int getValue() {
    var increment = prefs.getInt("incrementNumber") ?? 0;
    return increment;
  }

  Future<bool> increment() async {
    var increment = await prefs.getInt("incrementNumber") ?? 0;
    increment = increment + 1;
    await prefs.setInt("incrementNumber", increment);
    return true;
  }

  Future<bool> decrement() async {
    var increment = await prefs.getInt("incrementNumber") ?? 0;
    increment = increment - 1;
    await prefs.setInt("incrementNumber", increment);
    return true;
  }

  Future<bool> reset() async {
    await prefs.setInt("incrementNumber", 0);
    return true;
  }
}
