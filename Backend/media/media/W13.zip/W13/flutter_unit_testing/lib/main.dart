import 'package:flutter/material.dart';
import 'package:flutter_unit_testing/screens/home.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'utils/counter.dart';

Future<bool> init_my_app() async {
  counter.init();
  return true;
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await init_my_app();
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
    );
  }
}
