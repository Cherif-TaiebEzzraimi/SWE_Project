package com.example.report_error_remote_firebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
