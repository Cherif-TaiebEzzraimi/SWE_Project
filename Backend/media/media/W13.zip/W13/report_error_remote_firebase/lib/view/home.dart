import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Hello..')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            var t = 1 ~/ 0;
            print('reach this line ?');
          },
          child: Text('Click here'),
        ),
      ),
    );
  }
}
